using UnityEngine;

public class CharacterShooting : MonoBehaviour
{
    public Transform firePoint;
    public GameObject bulletPrefab;
    public float bulletForce = 10f;

    private void Update()
    {
        // Check for input to shoot bullets
        if (Input.GetButtonDown("Fire1")) // Adjust the input button as needed
        {
            Shoot();
        }
    }

    private void Shoot()
    {
        // Create a new bullet from the prefab at the firePoint's position and rotation
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);

        // Get the Rigidbody2D component of the bullet
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();

        // Check if the Rigidbody2D component exists
        if (rb != null)
        {
            // Set the velocity of the bullet to match the character's direction
            rb.velocity = transform.right * bulletForce;

            // Attach the bullet as a child of the character
            bullet.transform.parent = transform;

            // Destroy the bullet after a certain time (adjust as needed)
            Destroy(bullet, 2f);
        }
        else
        {
            Debug.LogError("Rigidbody2D component not found on the bullet.");
        }
    }
}
