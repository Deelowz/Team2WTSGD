using UnityEngine;

public class PlayerShooting : MonoBehaviour
{
    public GameObject bulletPrefab;
    public Transform firePoint;
    public float fireRate = 0.5f; // Rate of fire in seconds

    private float nextFireTime = 0f;

    private void Update()
    {
        if (Input.GetButtonDown("Fire1") && Time.time > nextFireTime)
        {
            Shoot();
            nextFireTime = Time.time + 1 / fireRate;
        }
    }

    private void Shoot()
    {
        // Instantiate a bullet and set its position and direction
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
        // Add logic to set the bullet's speed and damage

        // Destroy the bullet after a certain time if it doesn't hit anything
        Destroy(bullet, 2f);
    }
}
