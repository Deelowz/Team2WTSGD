using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    public int maxHealth = 100;
    private int currentHealth;

    private void Start()
    {
        currentHealth = maxHealth;
    }

    public void TakeDamage(int damageAmount)
    {
        currentHealth -= damageAmount;

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        // Handle player death here, such as displaying a game over screen or resetting the level.
        Debug.Log("Player has died!");
        // Example: You can reload the current scene to restart the game.
        // SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
