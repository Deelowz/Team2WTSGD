using UnityEngine;
using System.Collections;

public class PlayerShooting : MonoBehaviour
{
    public Transform firePoint;
    public GameObject bulletPrefab;
    public float bulletForce = 10f;
    public int maxBulletCount = 50;
    public float timeBetweenShots = 0.5f;
    public AudioSource shootingSound;

    private int currentBulletCount;
    private float lastShotTime;
    private bool isRecharging; 
    private float rechargingSpeed; 

    private void Start()
    {
        currentBulletCount = maxBulletCount;
        isRecharging = false; 
        rechargingSpeed = 1.0f; 
    }

    private void Update()
    {
        
        if (Input.GetButtonDown("Fire1") && Time.time - lastShotTime >= timeBetweenShots)
        {
            Shoot();
            if (shootingSound != null)
            {
                Debug.Log("Playing shooting sound");
                shootingSound.Play();
            }
                
        }
    }

    private void Shoot()
    {
        if (currentBulletCount > 0)
        {
            GameObject bullet = Instantiate(bulletPrefab, firePoint.position, transform.rotation);

            Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();

            if (rb != null)
            {
                rb.velocity = transform.right * bulletForce;

                currentBulletCount--;
                lastShotTime = Time.time;
                StartCoroutine(RechargeBullets());
                
                Destroy(bullet, 2f);
            }
            else
            {
                Debug.LogError("Rigidbody2D component not found on the bullet.");
            }
        }
        else
        {
            isRecharging = true; // bullets empty, start charge
        }
    }

    private IEnumerator RechargeBullets()
    {
        while (isRecharging)
        {
            yield return new WaitForSeconds(1.0f);
        
            if (currentBulletCount < maxBulletCount)
            {
                currentBulletCount += (int)rechargingSpeed;
                currentBulletCount = Mathf.Min(currentBulletCount, maxBulletCount);
            }
            else
            {
                isRecharging = false;
                rechargingSpeed = 0; // Reset reloadSpeed
            }
        }
    }
}