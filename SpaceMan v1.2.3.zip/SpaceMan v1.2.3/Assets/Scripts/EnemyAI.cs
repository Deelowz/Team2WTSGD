using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public float moveSpeed = 3f;
    public Transform player;
    public float aggroRange = 10f;
    public float attackRange = 1.5f;

    private int damageAmount = 10; // Damage amount when the enemy attacks

    private int maxHealth = 50; // Maximum health of the enemy
    private int currentHealth; // Current health of the enemy

    public int GetDamageAmount()
    {
        return damageAmount;
    }

    private void Start()
    {
        currentHealth = maxHealth; // Initialize current health to max health when the enemy is created.
    }

    private void Update()
    {
        if (player != null)
        {
            float distanceToPlayer = Vector2.Distance(transform.position, player.position);

            if (currentHealth > 0) // Check if the enemy is still alive
            {
                if (distanceToPlayer < aggroRange)
                {
                    Vector2 moveDirection = (player.position - transform.position).normalized;
                    transform.Translate(moveDirection * moveSpeed * Time.deltaTime);

                    if (distanceToPlayer < attackRange)
                    {
                        AttackPlayer();
                    }
                }
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("PlayerBullet"))
        {
            // Reduce the enemy's health when hit by a bullet
            TakeDamage();
            // Destroy the bullet
            Destroy(collision.gameObject);
        }
        else if (collision.gameObject.CompareTag("Player"))
        {
            // Optionally perform any actions when the player collides with the enemy.
            // For example, you can play a death animation or remove the enemy from the scene.
            // ...
            // Then, you can destroy the enemy GameObject.
            Destroy(gameObject);
        }
    }

    private void AttackPlayer()
    {
        PlayerHealth playerHealth = player.GetComponent<PlayerHealth>();

        if (playerHealth != null)
        {
            playerHealth.TakeDamage(damageAmount);
        }
    }

    private void TakeDamage()
    {
        currentHealth -= damageAmount;
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        // Perform any actions when the enemy dies (e.g., play a death animation).
        // ...

        // Destroy the enemy GameObject.
        Destroy(gameObject);
    }
}
