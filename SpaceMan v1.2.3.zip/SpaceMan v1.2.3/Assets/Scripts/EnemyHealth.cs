using UnityEngine;
using UnityEngine.UI;

public class EnemyHealth : MonoBehaviour
{
    public int maxHealth = 100; // Maximum health of the enemy
    private int currentHealth; // Current health of the enemy

    public Slider healthSlider; // Reference to the UI Slider

    void Start()
    {
        currentHealth = maxHealth;
        UpdateHealthUI();
    }

    // Update the health and UI Slider when the enemy takes damage
    public void TakeDamage(int damageAmount)
    {
        currentHealth -= damageAmount;
        currentHealth = Mathf.Max(currentHealth, 0); // Ensure health doesn't go below 0
        UpdateHealthUI();
    }

    // Update the UI Slider's value to reflect the current health
    private void UpdateHealthUI()
    {
        if (healthSlider != null)
        {
            healthSlider.value = (float)currentHealth / maxHealth;
        }
    }
}
